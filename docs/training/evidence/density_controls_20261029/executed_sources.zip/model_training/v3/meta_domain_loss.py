"""Differentiate through one support update before held-source supervision."""
import torch

def meta_domain_loss(model,support_loss,query_loss,inner_lr):
    if inner_lr<0:raise ValueError('Nonnegative inner learning rate required')
    params=dict(model.named_parameters());support=support_loss(None)
    gradients=torch.autograd.grad(support,tuple(params.values()),create_graph=True)
    fast={name:value-inner_lr*gradient for (name,value),gradient in zip(params.items(),gradients)}
    query=query_loss(fast)
    return .5*(support+query),support.detach(),query.detach()
